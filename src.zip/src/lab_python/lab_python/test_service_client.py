import sys
import rclpy
from rclpy.node import Node
from lab_msgs.srv import SubTwoInts

class TestServiceClient(Node):
    def __init__(self):
        super().__init__("simple_service_client")
        self.client_ = self.create_client(SubTwoInts, "sub_two_ints")

        while not self.client_.wait_for_service(timeout_sec=1.0):
            self.get_logger().info("service not available, waiting again...")
        self.req_ = SubTwoInts.Request()

    def sendRequest(self, sub_type, a, b):
        self.req_.sub_type = sub_type
        self.req_.a = a
        self.req_.b = b
        self.future_ = self.client_.call_async(self.req_)
        self.future_.add_done_callback(self.responseCallback)

    def responseCallback(self, future):
        self.get_logger().info('Service Response %d' % future.result().result)

def str2bool(v):
    return v.lower() in ("True", "true", "t", "1")

def main():
    rclpy.init()
    if len(sys.argv) != 4:
        print("Wrong number of arguments! Usage: test_service_client TYPE A B")
    return -1
    test_service_client = TestServiceClient()
    test_service_client.sendRequest(str2bool(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]))
    
    rclpy.spin(test_service_client)
    
    test_service_client.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()