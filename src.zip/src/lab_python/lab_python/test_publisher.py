import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from rcl_interfaces.msg import SetParametersResult
from rclpy.parameter import Parameter

class TestPublisher(Node):
    def __init__(self):
        super().__init__("test_publisher")
        self.declare_parameter('string_parameter', 'ROS')
        self.declare_parameter('int_parameter', 2)
        self.string_parameter_ = 'ROS'
        self.int_parameter_ = 2
        self.add_on_set_parameters_callback(self.paramChangeCallback)
        self.pub_ = self.create_publisher(String, "chatter", 10)
        self.counter_ = 0
        self.frequency_ = 1.0
        self.get_logger().info("Publishing at %d Hz" % self.frequency_)
        self.timer_ = self.create_timer(self.frequency_, self.timerCallback)

    def timerCallback(self):
        msg = String()
        msg.data = "Hello %s %d - counter: %d" % (self.string_parameter_, self.int_parameter_, self.counter_)
        self.pub_.publish(msg)
        self.counter_ += 1

    def paramChangeCallback(self, params):
        result = SetParametersResult()
        for param in params:
            if param.name == "string_parameter" and param.type_ == Parameter.Type.STRING:
                self.get_logger().info("Param string_parameter changed! New value is %s" % param.value)
                self.string_parameter_ = param.value
                result.successful = True
            if param.name == "int_parameter" and param.type_ == Parameter.Type.INTEGER:
                self.get_logger().info("Param int_parameter changed! New value is %d" % param.value)
                self.int_parameter_ = param.value
                result.successful = True
        return result
    
def main():
    rclpy.init()
    test_publisher = TestPublisher()
    rclpy.spin(test_publisher)
    test_publisher.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()