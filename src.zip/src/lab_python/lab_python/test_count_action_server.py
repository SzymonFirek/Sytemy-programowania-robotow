import time
import rclpy
from rclpy.action import ActionServer
from rclpy.node import Node
from lab_msgs.action import Count

class CountActionServer(Node):
    def __init__(self):
        super().__init__("test_count_action_server")
        self._action_server = ActionServer(
            self,
            Count,
            "count",
            self.execute_callback)

    def execute_callback(self, goal_handle):
        self.get_logger().info("Starting counter…")
        feedback_msg = Count.Feedback()
        feedback_msg.current_num = 0
        while feedback_msg.current_num < goal_handle.request.stop_num:
            feedback_msg.current_num = feedback_msg.current_num + 1
            self.get_logger().info('Feedback: {0}'.format(feedback_msg.current_num))
            goal_handle.publish_feedback(feedback_msg)
            time.sleep(1)
        goal_handle.succeed()
        result = Count.Result()
        result.is_finished = True     
def main(args=None):
    rclpy.init(args=args)
    count_action_server = CountActionServer()
    rclpy.spin(count_action_server)
    count_action_server.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()