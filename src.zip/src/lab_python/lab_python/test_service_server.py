import rclpy
from rclpy.node import Node
from lab_msgs.srv import SubTwoInts
class TestServiceServer(Node):
    def __init__(self):
        super().__init__("test_service_server")
        self.service_ = self.create_service(SubTwoInts, "sub_two_ints", self.serviceCallback)
        self.get_logger().info("Service sub_two_ints Ready")
    def serviceCallback(self, req, res):
        if req.sub_type:
            self.get_logger().info("New Request Received a: %d, b: %d" % (req.a, req.b))
            res.result = req.a - req.b
        else:
            self.get_logger().info("New Request Received b: %d, a: %d" % (req.b, req.a))
            res.result = req.b - req.a
        self.get_logger().info("Returning result: %d" % res.result)
        return res
def main():
    rclpy.init()
    
    test_service_server = TestServiceServer()
    rclpy.spin(test_service_server)

    test_service_server.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()