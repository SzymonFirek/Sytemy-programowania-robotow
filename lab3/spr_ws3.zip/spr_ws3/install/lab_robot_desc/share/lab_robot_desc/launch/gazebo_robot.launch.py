import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.substitutions import LaunchConfiguration, Command
from launch.actions import DeclareLaunchArgument
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

import xacro

from launch.actions import RegisterEventHandler
from launch.event_handlers import OnProcessExit

def generate_launch_description():

    # Check if we're told to use sim time
    use_sim_time = LaunchConfiguration('use_sim_time')

    # Check if we're told to use ros2 control
    use_ros2_control = LaunchConfiguration('use_ros2_control')

    # Process the URDF file
    pkg_name = 'lab_robot_desc'
    file_subpath_xacro = 'urdf/robot.urdf.xacro'

    # Additional parameters to gazebo server
    file_subpath_world = 'worlds/house.world'
    file_subpath_gazebo_params = 'config/gazebo_params.yaml'
    # parameters to twist mux node
    file_subpath_twist_mux = 'config/twist_mux.yaml'
  
    pkg_path = os.path.join(get_package_share_directory(pkg_name))
    xacro_file = os.path.join(pkg_path,file_subpath_xacro)

    # robot_description_config = xacro.process_file(xacro_file).toxml()
    robot_description_config = Command(['xacro ', xacro_file, ' use_ros2_control:=', use_ros2_control])

    # Use gazebo launch files
    gazebo_ros_dir = get_package_share_directory('gazebo_ros')

    # Use saved world
    world = os.path.join(get_package_share_directory(pkg_name),file_subpath_world)
    gazebo_params_file = os.path.join(get_package_share_directory(pkg_name),file_subpath_gazebo_params)

    twist_mux_params = os.path.join(get_package_share_directory(pkg_name),file_subpath_twist_mux)
    twist_mux = Node(
            package="twist_mux",
            executable="twist_mux",
            parameters=[twist_mux_params, {'use_sim_time': True}],
            remappings=[('/cmd_vel_out','/diff_cont/cmd_vel_unstamped')]
        )

    # Create a robot_state_publisher node
    params = {'robot_description': robot_description_config, 'use_sim_time': use_sim_time}
    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[params]
    )

    # Configurate the gazebo server
    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_dir, 'launch', 'gzserver.launch.py')
        ),
        launch_arguments={'world': world, 'extra_gazebo_args': '--ros-args --params-file ' + gazebo_params_file}.items()
    )

    # launch_arguments={'world': world}.items()
    # Configurate the gazebo client
    gazebo_client = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_dir, 'launch', 'gzclient.launch.py')
        )
    )

    # Spawn robot in the simualation enviroment
    spawn_entity = Node(package='gazebo_ros', executable='spawn_entity.py',
                    arguments=['-topic', 'robot_description',
                                '-entity', 'robot'],
                    output='screen')

    # nodes of ros2 control controller and broadcaster
    diff_drive_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["diff_cont"],
    )

    joint_broad_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_broad"],
    )

    # launching nodes with delays
    delayed_diff_drive_spawner = RegisterEventHandler(
        event_handler=OnProcessExit(
                target_action=spawn_entity,
                on_exit=[diff_drive_spawner],
            )
        )
    
    delayed_joint_broad_spawner= RegisterEventHandler(
        event_handler=OnProcessExit(
                target_action=spawn_entity,
                on_exit=[joint_broad_spawner],
            )
        )

    # Launch!
    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='Use sim time if true'),
        DeclareLaunchArgument(
            'use_ros2_control',
            default_value='true',
            description='Use ros2 control if true'),
        twist_mux,
        node_robot_state_publisher,
        gazebo_server,
        gazebo_client,
        spawn_entity,
        delayed_diff_drive_spawner,
        delayed_joint_broad_spawner
        ])