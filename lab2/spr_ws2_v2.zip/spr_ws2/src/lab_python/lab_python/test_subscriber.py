import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class TestSubscriber(Node):

    def __init__(self):
        super().__init__("test_subscriber")
        self.sub_ = self.create_subscription(String, "chatter", self.msgCallback, 10)
        self.sub_

    def msgCallback(self, msg):
        self.get_logger().info("Received: %s" % msg.data)


def main():
    rclpy.init()

    test_publisher = TestSubscriber()
    rclpy.spin(test_publisher)
    
    test_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()