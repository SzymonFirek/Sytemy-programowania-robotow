from setuptools import find_packages, setup

package_name = 'lab_python'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='robot',
    maintainer_email='robot@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'test_teleop_key = lab_python.test_teleop_key:main',
            'test_publisher = lab_python.test_publisher:main',
            'test_subscriber = lab_python.test_subscriber:main',
        ],
    },
)
